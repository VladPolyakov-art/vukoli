"""Vukoli: local server for voice and text mock-interview practice with an AI interviewer (Mike)."""

__version__ = "0.2.10"
DATA_VERSION = 1
APP_NAME = "interview-coach"
